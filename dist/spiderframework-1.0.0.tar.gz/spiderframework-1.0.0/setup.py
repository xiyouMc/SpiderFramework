from distutils.core import setup

setup(
    name='spiderframework',
    version='1.0.0',
    packages=[''],
    url='https://www.github.com/xiyouMc/SpiderFramework',
    license='',
    author='xiyouMc',
    author_email='pythondevelopermc@gmail.com',
    description='Spider Framework for you.'
)
